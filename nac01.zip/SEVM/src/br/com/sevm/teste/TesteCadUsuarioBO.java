package br.com.sevm.teste;

import javax.swing.JOptionPane;

import br.com.sevm.beans.Usuario;
import br.com.sevm.bo.UsuarioBO;

public class TesteCadUsuarioBO {
	public static void main(String[] args) {
		
		try {
			UsuarioBO abo =new UsuarioBO();
			Usuario a = new Usuario();
			a.setCodigo(Integer.parseInt(JOptionPane.showInputDialog("Codigo Usuario: ")));
			a.setNome(JOptionPane.showInputDialog("Nome do Usuario: "));
			a.setEmail(JOptionPane.showInputDialog("Email do Usuario: "));
			a.setSenha(JOptionPane.showInputDialog("Digite a senha: "));
			a.setSenha(JOptionPane.showInputDialog("Digite o tipo de Usuario: "));
			System.out.println(abo.newUsuario(a));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
