package br.com.sevm.teste;

import java.sql.Connection;

import br.com.sevm.conexao.Conexao;

public class ConexaoTeste {
	public static void main(String[] args) {
		Connection con = null;
		try {
			con = Conexao.conectarBanco();
			System.out.println("Conectado");
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				con.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
