package br.com.sevm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.sevm.beans.Usuario;
import br.com.sevm.conexao.Conexao;

public class UsuarioDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;

	public UsuarioDAO() throws Exception{
		con = Conexao.conectarBanco();
	}

	public Usuario getUsuario(int cod) throws Exception {	
		con.prepareStatement("SELECT * FROM SEVM_USUARIO WHERE CD_CPF=?");
		stmt.setInt(1, cod);
		rs = stmt.executeQuery();
		if(rs.next()) {
			return new Usuario(
					rs.getInt("CD_CPF"),
					rs.getString("NM_USUARIO"),
					rs.getString("EM_USUARIO"),
					rs.getString("PW_USUARIO"),
					rs.getString("TIPO_PERMISSAO")
					);
		}else {
			return new Usuario();
		}
	}
	public int apagarUsuario(int cod) throws Exception {
		stmt = con.prepareStatement("delete from SEVM_USUARIO WHERE CD_CPF=?");
		stmt.setInt(1,cod);
		return stmt.executeUpdate();

	}
	public void fechar() throws Exception{
		con.close();
	}

	public int cadastrarUsuario(Usuario usu) throws Exception {
		stmt = con.prepareStatement
				("INSERT INTO SEVM_USUARIO (NM_USUARIO, CD_CPF, EM_USUARIO, PW_USUARIO, TIPO_PERMISSAO) VALUES(?,?,?,?,?)");
		stmt.setInt(2, usu.getCodigo());
		stmt.setString(1, usu.getNome());
		stmt.setString(3, usu.getEmail());
		stmt.setString(4, usu.getSenha());
		stmt.setString(5, usu.getTipo());
		return stmt.executeUpdate();
	}
}
