package br.com.sevm.bo;

import br.com.sevm.beans.Usuario;
import br.com.sevm.dao.UsuarioDAO;

public class UsuarioBO {

	public String newUsuario(Usuario objUsuario)throws Exception{
		if (objUsuario.getCodigo() == 0) {
			return "Numero invalido";
		}


		if (objUsuario.getNome().length() >= 30 || objUsuario.getNome().length() <= 10 ){
			return "Preencher o nome completo";
		}

		if (objUsuario.getNome().isEmpty()) {
			return "O campo est� vazio";
		}

		if (objUsuario.getNome().contains("@,/,!,#,$,%,*")) {
			return "Somente letras";
		}

		//Valida��o email
		if (objUsuario.getEmail().length()==0) {
			return "Email vazio";
		}
		if(objUsuario.getEmail().indexOf(" ")>=0 || objUsuario.getEmail().indexOf("@")<0 || objUsuario.getEmail().indexOf(".")<0) {
			return "Email inv�lido";
		}


		//Valida��o SENHA
		if(objUsuario.getSenha().length() < 8 || objUsuario.getSenha().length() < 21) {
			return "A senha deve ter entre 8 e 20 caracteres";
		}
		if(objUsuario.getSenha().length()==0 || objUsuario.getSenha().indexOf(" ")>=0) {
			return "Senha inv�lida";
		}


	UsuarioDAO dao = new UsuarioDAO();
	Usuario usu = dao.getUsuario(objUsuario.getCodigo());
	if (usu.getCodigo() > 0) {
		return "Usuario j� cadastrado";
	}

	objUsuario.setNome(objUsuario.getNome().toUpperCase());
	int x = dao.cadastrarUsuario(objUsuario);
	dao.fechar();
	return x + " aluno(s) cadastrado(s)";

	}
}




