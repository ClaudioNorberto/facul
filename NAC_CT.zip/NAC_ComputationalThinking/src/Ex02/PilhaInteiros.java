package Ex02;

public class PilhaInteiros{
	private int topoPilha;
	private int[] linhaPilha;

	public PilhaInteiros(int conteudo) {
		linhaPilha = new int[conteudo];
		topoPilha = -1;
	}

	public int topo() {
		return linhaPilha[topoPilha];
	}
	
	public void empilha(int p) {
		topoPilha++;
		linhaPilha[topoPilha] = p;
	}

	public int desempilha() {
		return linhaPilha[topoPilha--];
	}

	public boolean isCheia() {
		if(topoPilha == linhaPilha.length - 1) 
			return true;
		else 
			return false;
	}

	public boolean isVazia() {
		if(topoPilha == -1) 
			return true;
		else 
			return false;
	}

}
