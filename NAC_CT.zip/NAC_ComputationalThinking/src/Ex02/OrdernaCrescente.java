package Ex02;

public class OrdernaCrescente{
	public static void main(String[] args) {

		int [] vetorInteiros = {9,6,3,8,5,2,7,4,1,0};
		int maiorNum = vetorInteiros[0];

		for (int i = 0; i < vetorInteiros.length; i++) {
			if (vetorInteiros[i] > maiorNum) {
				maiorNum = vetorInteiros[i];
			}
		}

		PilhaInteiros primeiraPilha = new PilhaInteiros(vetorInteiros.length);
		PilhaInteiros segundaPilha = new PilhaInteiros(vetorInteiros.length);

		while(!primeiraPilha.isVazia()) {
			int i = 0;
			for (i = 0; i < vetorInteiros.length; i++) {
				if (maiorNum == vetorInteiros[i]) {
					primeiraPilha.empilha(vetorInteiros[i]);
					maiorNum--;
				}
				else {
					segundaPilha.empilha(vetorInteiros[i]);
				}

			}
			i = 0;

		}

		for (int i = 0; i < vetorInteiros.length; i++) {
			vetorInteiros[i] = segundaPilha.desempilha();
		}
	}
}
