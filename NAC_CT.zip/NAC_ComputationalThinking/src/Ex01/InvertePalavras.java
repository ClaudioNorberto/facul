package Ex01;

import Ex01.Pilha;

public class InvertePalavras{
	public static void main(String[] args) {

		String fraseCompleta = "ontem choveu mas hoje fez sol";
		String[] vetPalavras = fraseCompleta.split(" ");
		Pilha p = new Pilha(30);
		StringBuffer palavrasInvertidas = new StringBuffer();

		for (int i = 0; i < vetPalavras.length; i++) {
			char [] palavras = vetPalavras[i].toCharArray();
			for (int j = 0; j < palavras.length; j++) {
				p.empilha(palavras[j]);
			}
			while(p.isVazia() == false) {
				palavrasInvertidas.append(p.desempilha());
			}
			palavrasInvertidas.append(" ");
		}

		System.out.println(palavrasInvertidas);
	}
}
