package Ex01;

public class Pilha {

	private int topoPilha;
	private char[] linhaPilha;

	public Pilha(int conteudo) {
		linhaPilha = new char[conteudo];
		topoPilha = -1;
	}

	public char topo() {
		return linhaPilha[topoPilha];
	}

	public void empilha(char p) {
		topoPilha++;
		linhaPilha[topoPilha] = p;
	}

	public char desempilha() {
		return linhaPilha[topoPilha--];
	}	

	public boolean isCheia() {
		if(topoPilha == linhaPilha.length - 1) 
			return true;
		else 
			return false;
	}

	public boolean isVazia() {
		if(topoPilha == -1) 
			return true;
		else 
			return false;
	}
}