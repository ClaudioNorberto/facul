package Ex03;

import java.util.List;

public class ConsumoPlan {

	public static void main(String[] args) {
		public List<Consumo> leDadosConsumo(){
			Consumo.add("");
			
			
			//FileInputStream fileP = null;
			//File file = new File("D:\\FIAP\\consumo.csv");
			//try {
			//	fileP = new FileInputStream(file);
			//} catch (FileNotFoundException e) {
			//	e.printStackTrace();
			//}
			
		}
		
		
		
		
		
		System.out.println(fileP);
		
		

	}

}
