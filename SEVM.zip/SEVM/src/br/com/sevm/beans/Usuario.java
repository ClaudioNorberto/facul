package br.com.sevm.beans;

public class Usuario implements Comparable<Usuario>{
	private int codigo;
	private String nome;
	private String email;
	private String senha;
	private String tipo;
	
	public int compareTo(Usuario porNome) {
		return -nome.compareTo(porNome.nome);
	}

	public Usuario(int codigo, String nome, String email, String senha, String tipo) {
		super();
		this.codigo = codigo;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.tipo = tipo;
	}
	public Usuario() {
		super();
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}



}
