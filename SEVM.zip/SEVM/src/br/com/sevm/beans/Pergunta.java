package br.com.sevm.beans;

public class Pergunta {
	private int codigo;
	private String pergunta;
	private String resposta;
	private String dificuldade;

	public Pergunta() {
		super();
	}
	public Pergunta(int codigo, String pergunta, String resposta, String dificuldade) {
		super();
		this.codigo = codigo;
		this.pergunta = pergunta;
		this.resposta = resposta;
		this.dificuldade = dificuldade;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getPergunta() {
		return pergunta;
	}
	public void setPergunta(String pergunta) {
		this.pergunta = pergunta;
	}
	public String getResposta() {
		return resposta;
	}
	public void setResposta(String resposta) {
		this.resposta = resposta;
	}
	public String getDificuldade() {
		return dificuldade;
	}
	public void setDificuldade(String dificuldade) {
		this.dificuldade = dificuldade;
	}
}
