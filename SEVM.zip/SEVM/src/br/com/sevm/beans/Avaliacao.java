package br.com.sevm.beans;

public class Avaliacao {
	private int codigo;
	private String dificuldade;
	private int qtdPergunta;
	private float nota;
	private Usuario usuario;
	private Pergunta pergunta;
	
	public Avaliacao() {
		super();
	}
	public Avaliacao(int codigo, String dificuldade, int qtdPergunta, float nota, Usuario usuario, Pergunta pergunta) {
		super();
		this.codigo = codigo;
		this.dificuldade = dificuldade;
		this.qtdPergunta = qtdPergunta;
		this.nota = nota;
		this.usuario = usuario;
		this.pergunta = pergunta;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDificuldade() {
		return dificuldade;
	}
	public void setDificuldade(String dificuldade) {
		this.dificuldade = dificuldade;
	}
	public int getQtdPergunta() {
		return qtdPergunta;
	}
	public void setQtdPergunta(int qtdPergunta) {
		this.qtdPergunta = qtdPergunta;
	}
	public float getNota() {
		return nota;
	}
	public void setNota(float nota) {
		this.nota = nota;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Pergunta getPergunta() {
		return pergunta;
	}
	public void setPergunta(Pergunta pergunta) {
		this.pergunta = pergunta;
	}
	

}
