package br.com.sevm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.sevm.beans.Avaliacao;

/**
 * Esta classe permite gerenciar as perguntas respondidas avaliando o desempenho do aluno
 * realiza o CRUD na tabela T_AVALIACAO que possui: 
 * PK: CD_AVALIACAO
 * NV_DIFICULDADE
 * QT_PERGUNTA
 * NT_AVALIACAO
 * @author Douglas
 * @author Claudio
 * @see br.com.sevm.beans.Usuario
 * @see br.com.sevm.beans.Pergunta
 * @param	cadastarAvaliacao - insere os dados para um tipo de avalia��o
 * @param	alterarAvaliacao - altera um item da avalia��o
 * @param	apagarAvaliacao - apaga uma prova
 * @version 10.2
 * @since 10.0
 */

public class AvaliacaoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet result;

	public Avaliacao getAvaliacao(int codigo)throws Exception{
		stmt = con.prepareStatement(
				"SELECT * FROM T_AVALIACAO WHERE CD_AVALIACAO=?"
				);
		stmt.setInt(1, codigo);
		result = stmt.executeQuery();
		if(result.next()) {
			return new Avaliacao(
					result.getInt("CD_AVALIACAO"),
					result.getString("NV_DIFICULDADE"),
					result.getInt("QT_PERGUNTA"),
					result.getFloat("NT_AVALIACAO"),
					new UsuarioDAO().getUsuario(result.getInt("CD_USUARIO")),
					new PerguntaDAO().getPergunta(result.getInt("CD_PERGUNTA"))
					);
		}else {
			return new Avaliacao();
		}
	}

	public int apagarAvaliacao(int codigo) throws Exception{
		stmt = con.prepareStatement(
				"DELETE FROM T_AVALIACAO WHERE CD_AVALIACAO=?"
				);
		stmt.setInt(1, codigo);
		return stmt.executeUpdate();
	}

	public int cadastrarAvaliacao(Avaliacao ava) throws Exception{
		stmt = con.prepareStatement(
				"INSERT INTO T_AVALIACAO (CD_AVALIACAO, NV_DIFICULDADE, QT_PERGUNTA, NT_AVALIACAO, CD_USUARIO, CD_PERGUNTA) VALUES(?,?,?,?,?,?)"
				);
		stmt.setInt(1, ava.getCodigo());
		stmt.setString(2, ava.getDificuldade());
		stmt.setInt(3, ava.getQtdPergunta());
		stmt.setFloat(4, ava.getNota());
		stmt.setInt(5, ava.getUsuario().getCodigo());
		stmt.setInt(6, ava.getPergunta().getCodigo());
		return stmt.executeUpdate();
	}

	public int alterarAvaliacao(int codigo, String novaDificuldade, int novaQtd, float novaNota)throws Exception {
		stmt = con.prepareStatement(
				"UPDATE T_AVALIACAO SET NV_DIFICULDADE=?, QT_PERGUNTA=?, NT_AVALIACAO=? WHERE CD_AVALIACAO=?"
				);
		stmt.setString(1, novaDificuldade);
		stmt.setInt(2, novaQtd);
		stmt.setFloat(3, novaNota);
		stmt.setInt(4, codigo);
		Avaliacao ava = new Avaliacao();
		ava.setDificuldade(novaDificuldade);
		ava.setQtdPergunta(novaQtd);
		ava.setNota(novaNota);
		return stmt.executeUpdate();
	}

	public void fecharConexao()throws Exception{
		con.close();
	}

}
