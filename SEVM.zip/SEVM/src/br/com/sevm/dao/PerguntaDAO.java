package br.com.sevm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.sevm.beans.Pergunta;
import br.com.sevm.beans.Usuario;

/**
 * Esta classe permite realizar o CRUD na tabela T_PERGUNTA que possui: 
 * PK: CD_PERGUNTA
 * DS_PERGUNTA
 * DS_RESPOSTA
 * DF_PERGUNTA
 * @author Douglas
 * @author Claudio
 * @see br.com.sevm.beans.Usuario
 * @see br.com.sevm.beans.Pergunta
 * @param	cadastarPergunta - insere os dados de uma quest�o da prova
 * @param	alterarPergunta - altera um item da quest�o
 * @param	apagarPergunta - apaga uma quest�o
 * @version 10.2
 * @since 10.0
 */

public class PerguntaDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet result;
	

	public Pergunta getPergunta(int codigo)throws Exception{
		stmt = con.prepareStatement(
				"SELECT * FROM T_PERGUNTA WHERE CD_PERGUNTA=?"
				);
		stmt.setInt(1, codigo);
		result = stmt.executeQuery();
		if(result.next()) {
			return new Pergunta(
					result.getInt("CD_PERGUNTA"),
					result.getString("DS_PERGUNTA"),
					result.getString("DS_RESPOSTA"),
					result.getString("DF_PERGUNTA")
					);
		}else {
			return new Pergunta();
		}
	}
	
	public int apagarPergunta(int codigo) throws Exception{
		stmt = con.prepareStatement(
				"DELETE FROM T_QUESTAO WHERE CD_PERGUNTA=?"
				);
		stmt.setInt(1, codigo);
		return stmt.executeUpdate();
	}
	
	public int cadastrarPergunta(Pergunta perg) throws Exception{
		stmt = con.prepareStatement(
				"INSERT INTO T_QUESTAO (CD_PERGUNTA, DS_PERGUNTA, DS_RESPOSTA, DF_PERGUNTA) VALUES(?,?,?,?)"
				);
		stmt.setInt(1, perg.getCodigo());
		stmt.setString(2, perg.getPergunta());
		stmt.setString(3, perg.getResposta());
		stmt.setString(4, perg.getDificuldade());
		return stmt.executeUpdate();
	}
	
	public int alterarPergunta(int codigo, String novaPergunta, String novaResposta, String novaDificuldade)throws Exception {
		stmt = con.prepareStatement(
				"UPDATE T_QUESTAO SET DS_PERGUNTA=?, DS_RESPOSTA=?, DF_PERGUNTA=? WHERE CD_PERGUNTA=?"
				);
		stmt.setString(1, novaPergunta);
		stmt.setString(2, novaResposta);
		stmt.setString(3, novaDificuldade);
		stmt.setInt(4, codigo);
		Usuario usu = new Usuario();
		usu.setNome(novaPergunta);
		usu.setEmail(novaResposta);
		usu.setSenha(novaDificuldade);
		return stmt.executeUpdate();
	}
	
	public void fecharConexao()throws Exception{
		con.close();
	}
	
	
}
