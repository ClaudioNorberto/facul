package br.com.sevm.teste;

import javax.swing.JOptionPane;

import br.com.sevm.beans.Avaliacao;
import br.com.sevm.dao.AvaliacaoDAO;
import br.com.sevm.dao.UsuarioDAO;



public class TesteCadAvaDAO {

	public static void main(String[] args) {
		AvaliacaoDAO dao = null;
		try {
			dao = new AvaliacaoDAO();
			UsuarioDAO usuDAO = new UsuarioDAO();
	
			if(dao.cadastrarAvaliacao(new Avaliacao(
					Integer.parseInt
					(JOptionPane.showInputDialog("Codigo da avalia��o: ")),
					JOptionPane.showInputDialog("Nivel de dificuldade: "),
					Integer.parseInt
					(JOptionPane.showInputDialog("Quantidade de perguntas: ")),
					Float.parseFloat
					(JOptionPane.showInputDialog("Nota da avalia��o: ") 
					))==0) {
				System.out.println("Avalia��o n�o cadastrada");
			}else {
				System.out.println("Avalia��o cadastrada com sucesso!");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				dao.fecharConexao();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

	}

}
