package br.com.sevm.teste;

import javax.swing.JOptionPane;

import br.com.sevm.beans.Usuario;
import br.com.sevm.dao.UsuarioDAO;

public class TesteCadUsuario {

	public static void main(String[] args) {
		UsuarioDAO dao = null;
		try {
			dao = new UsuarioDAO();

			if (dao.cadastrarUsuario(new Usuario(
					Integer.parseInt
					(JOptionPane.showInputDialog("Codigo do aluno: ")),
					JOptionPane.showInputDialog("Nome do aluno: "),
					JOptionPane.showInputDialog("Email do aluno: "),
					JOptionPane.showInputDialog("Senha do aluno: "), 
					JOptionPane.showInputDialog("Tipo do aluno: ")
					))==0) {
				System.out.println("N�o cadastro");
			} else {
				System.out.println("Cadastrado com sucesso!");
			}
		} catch (Exception e) {
			e.printStackTrace();			
		} finally {
			try {
				dao.fechar();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
