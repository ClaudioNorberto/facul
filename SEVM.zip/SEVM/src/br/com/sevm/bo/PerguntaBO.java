package br.com.sevm.bo;

import br.com.sevm.beans.Pergunta;

/**
 * Esta classe faz a valida��o dos dados das perguntas
 * @author Claudio
 * @see br.com.sevm.beans.Pergunta
 * @version 10.0
 * @since 10.0
 */

public class PerguntaBO {
	public String newPergunta(Pergunta objPergunta)throws Exception{
		if (objPergunta.getCodigo() == 0) {
			return "Numero invalido";
		}
		if (objPergunta.getPergunta().isEmpty()) {
			return "O campo est� vazio";
		}
		if(objPergunta.getPergunta().length() < 5 || objPergunta.getPergunta().length() < 201) {
			return "Pergunta muito pequena ou muito grande";
		}
		return null;
	}
}
