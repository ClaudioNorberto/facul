package br.com.sevm.bo;

import br.com.sevm.beans.Avaliacao;

/**
 * Esta classe faz a valida��o dos dados da avalia��o
 * @author Claudio
 * @see br.com.sevm.beans.Avaliacao
 * @version 10.0
 * @since 10.0
 */
public class AvaliacaoBO {
	public String newAvaliacao(Avaliacao objAvaliacao)throws Exception{
		if (objAvaliacao.getCodigo() == 0) {
			return "Numero invalido";
		}
		return null;
	
	}
}

